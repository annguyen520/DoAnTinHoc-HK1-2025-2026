﻿#include <iostream>
#include <filesystem>
#include <cctype>
#include "Header.h"
#include "AVLTree.h"
using namespace std;
namespace fs = std::filesystem;

int main() {
    string filename = "D:\\SourceCode-DH52200308\\Project1\\x64\\Debug\\student_exam_scores.csv";
    cout << "Dang doc file CSV...\n";

    auto data = read_csv(filename);
    cout << "Doc thanh cong!\n";
    cout << "So cot: " << data.size() << endl;

    if (data.empty()) {
        cerr << "Khong co du lieu trong file CSV!\n";
        return 1;
    }

    string outFile = "student_exam_scores.txt";
    write_to_txt(outFile, data);
    cout << "Da ghi toan bo du lieu vao " << outFile << " thanh cong!\n";

    AVLTree<int> tree_student_id;
    AVLTree<double> tree_hours_studied, tree_sleep_hours, tree_attendance, tree_prev_scores, tree_exam_score;
    size_t rows = data[0].second.size();
    cout << "So dong du lieu: " << rows << endl;

    for (size_t i = 0; i < rows; ++i) {
        const Cell& c0 = data[0].second[i];
        if (holds_alternative<int>(c0))
            tree_student_id.insert(get<int>(c0));
        else if (holds_alternative<double>(c0))
            tree_student_id.insert((int)get<double>(c0));
        else if (holds_alternative<string>(c0)) {
            string s = get<string>(c0), digits;
            for (char ch : s) if (isdigit(ch)) digits += ch;
            if (!digits.empty()) {
                try { tree_student_id.insert(stoi(digits)); }
                catch (...) {}
            }
        }

        auto insertDouble = [](AVLTree<double>& t, const Cell& c) {
            if (holds_alternative<double>(c))
                t.insert(get<double>(c));
            else if (holds_alternative<int>(c))
                t.insert((double)get<int>(c));
            };

        insertDouble(tree_hours_studied, data[1].second[i]);
        insertDouble(tree_sleep_hours, data[2].second[i]);
        insertDouble(tree_attendance, data[3].second[i]);
        insertDouble(tree_prev_scores, data[4].second[i]);
        insertDouble(tree_exam_score, data[5].second[i]);
    }

    cout << "\nDa xay dung thanh cong cac cay AVL!\n";
    cout << "\n=== KET QUA DUYET CAY ===\n";

    auto printAll = [](auto& name, auto& tree) {
        cout << "\n--- " << name << " ---\n";
        cout << "In-order  (LNR): "; tree.displayInorder();
        cout << "Pre-order (NLR): "; tree.displayPreorder();
        cout << "Post-order(LRN): "; tree.displayPostorder();
        };

    printAll("STUDENT ID", tree_student_id);
    printAll("HOURS STUDIED", tree_hours_studied);
    printAll("SLEEP HOURS", tree_sleep_hours);
    printAll("ATTENDANCE PERCENT", tree_attendance);
    printAll("PREVIOUS SCORES", tree_prev_scores);
    printAll("EXAM SCORE", tree_exam_score);

    cout << "\nDa ghi file student_exam_scores.txt va xay dung cay AVL hoan tat!\n";
    return 0;
}
