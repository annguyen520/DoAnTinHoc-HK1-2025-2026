﻿#include <iostream>
#include <filesystem>
#include "Header.h"
using namespace std;
namespace fs = std::filesystem;

int main() {
    string filename = "D:\\t\\Project1\\x64\\Debug\\student_exam_scores.csv"; // ép đường dẫn tuyệt đối

    cout << "Working directory: " << fs::current_path() << endl;
    cout << "Dang doc file CSV...\n";

    auto data = read_csv(filename); // thử mở lại

    cout << "Doc thanh cong!\n";
    cout << "So cot: " << data.size() << endl;

    if (!data.empty()) {
        cout << "So dong: " << data[0].second.size() << endl;
        cout << "Cot dau tien: " << data[0].first << endl;
    }

    write_to_txt("student_exam_scores.txt", data);
    cout << "Da ghi toan bo du lieu vao student_exam_scores.txt thanh cong!\n";

    // Hiển thị toàn bộ dữ liệu đã đọc
    cout << "\n===== Noi dung file CSV =====\n";
    for (size_t i = 0; i < data[0].second.size(); ++i) { // lặp qua từng dòng
        for (size_t j = 0; j < data.size(); ++j) {       // lặp qua từng cột
            const auto& val = data[j].second[i];
            if (holds_alternative<int>(val))
                cout << get<int>(val);
            else if (holds_alternative<double>(val))
                cout << get<double>(val);
            else
                cout << get<string>(val);

            if (j != data.size() - 1) cout << ", ";
        }
        cout << endl;
    }

    return 0;
}
