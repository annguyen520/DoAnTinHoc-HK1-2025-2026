﻿#pragma once
#include <string>
#include <vector>
#include <variant>
using namespace std;

// Định nghĩa kiểu dữ liệu cho từng ô trong CSV
using Cell = variant<int, double, string>;

// Mỗi cột trong CSV gồm tên cột và danh sách giá trị
using CSVColumn = pair<string, vector<Cell>>;

// Khai báo hàm
vector<CSVColumn> read_csv(const string& filename);
void write_to_txt(const string& filename, const vector<CSVColumn>& data);
