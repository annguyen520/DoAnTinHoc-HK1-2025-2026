﻿#include "Header.h"
#include <fstream>
#include <sstream>
#include <iostream>
#include <stdexcept>

using namespace std;

// ====== ĐỌC FILE CSV ======
vector<CSVColumn> read_csv(const string& filename) {
    ifstream myFile(filename);
    if (!myFile.is_open()) {
        cerr << "Khong the mo file: " << filename << endl;
        cerr << "Hay kiem tra duong dan hoac vi tri file CSV.\n";
        exit(1);
    }

    vector<CSVColumn> result;
    string line;

    // Đọc tiêu đề (tên cột)
    if (getline(myFile, line)) {
        stringstream ss(line);
        string colname;
        while (getline(ss, colname, ',')) {
            result.push_back({ colname, vector<Cell>{} });
        }
    }

    // Đọc từng dòng dữ liệu
    while (getline(myFile, line)) {
        stringstream ss(line);
        string token;
        size_t colIdx = 0;

        while (getline(ss, token, ',')) {
            if (colIdx >= result.size()) break;

            // Loại bỏ dấu " nếu có
            if (!token.empty() && token.front() == '"' && token.back() == '"') {
                token = token.substr(1, token.size() - 2);
                result[colIdx].second.push_back(token);
            }
            else {
                try {
                    if (token.find('.') != string::npos)
                        result[colIdx].second.push_back(stod(token));
                    else
                        result[colIdx].second.push_back(stoi(token));
                }
                catch (...) {
                    result[colIdx].second.push_back(token);
                }
            }

            colIdx++;
        }
    }

    myFile.close();
    return result;
}

// ====== GHI TOÀN BỘ NỘI DUNG RA FILE TXT ======
void write_to_txt(const string& filename, const vector<CSVColumn>& data) {
    ofstream out(filename);
    if (!out.is_open()) {
        cerr << "Khong the mo file de ghi: " << filename << endl;
        exit(1);
    }

    // Ghi tiêu đề
    for (size_t j = 0; j < data.size(); ++j) {
        out << data[j].first;
        if (j != data.size() - 1) out << ",";
    }
    out << "\n";

    // Ghi toàn bộ dữ liệu
    size_t nrows = data[0].second.size();
    for (size_t i = 0; i < nrows; ++i) {
        for (size_t j = 0; j < data.size(); ++j) {
            const Cell& val = data[j].second[i];
            if (holds_alternative<int>(val))
                out << get<int>(val);
            else if (holds_alternative<double>(val))
                out << get<double>(val);
            else
                out << get<string>(val);

            if (j != data.size() - 1) out << ",";
        }
        out << "\n";
    }

    out.close();
}
