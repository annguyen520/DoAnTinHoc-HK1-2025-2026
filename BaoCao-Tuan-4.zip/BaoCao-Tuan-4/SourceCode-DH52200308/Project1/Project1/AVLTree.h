﻿#pragma once
#include <iostream>
#include <algorithm>
using namespace std;

// =======================
// CẤU TRÚC NODE AVL
// =======================
template <typename T>
struct AVLNode {
    T key;
    int height;
    AVLNode* left;
    AVLNode* right;

    AVLNode(T val) : key(val), height(1), left(nullptr), right(nullptr) {}
};

// =======================
// LỚP CÂY AVL
// =======================
template <typename T>
class AVLTree {
private:
    AVLNode<T>* root;

    int height(AVLNode<T>* node) { return node ? node->height : 0; }

    int getBalance(AVLNode<T>* node) {
        return node ? height(node->left) - height(node->right) : 0;
    }

    AVLNode<T>* rightRotate(AVLNode<T>* y) {
        AVLNode<T>* x = y->left;
        AVLNode<T>* T2 = x->right;
        x->right = y;
        y->left = T2;
        y->height = max(height(y->left), height(y->right)) + 1;
        x->height = max(height(x->left), height(x->right)) + 1;
        return x;
    }

    AVLNode<T>* leftRotate(AVLNode<T>* x) {
        AVLNode<T>* y = x->right;
        AVLNode<T>* T2 = y->left;
        y->left = x;
        x->right = T2;
        x->height = max(height(x->left), height(x->right)) + 1;
        y->height = max(height(y->left), height(y->right)) + 1;
        return y;
    }

    AVLNode<T>* insertNode(AVLNode<T>* node, T key) {
        if (!node) return new AVLNode<T>(key);

        if (key < node->key)
            node->left = insertNode(node->left, key);
        else if (key > node->key)
            node->right = insertNode(node->right, key);
        else
            return node; // không chèn trùng

        node->height = 1 + max(height(node->left), height(node->right));
        int balance = getBalance(node);

        if (balance > 1 && key < node->left->key)
            return rightRotate(node);
        if (balance < -1 && key > node->right->key)
            return leftRotate(node);
        if (balance > 1 && key > node->left->key) {
            node->left = leftRotate(node->left);
            return rightRotate(node);
        }
        if (balance < -1 && key < node->right->key) {
            node->right = rightRotate(node->right);
            return leftRotate(node);
        }

        return node;
    }

    void clear(AVLNode<T>* node) {
        if (!node) return;
        clear(node->left);
        clear(node->right);
        delete node;
    }

    // ===== 3 kiểu duyệt =====
    void inorder(AVLNode<T>* node) {
        if (!node) return;
        inorder(node->left);
        cout << node->key << " ";
        inorder(node->right);
    }

    void preorder(AVLNode<T>* node) {
        if (!node) return;
        cout << node->key << " ";
        preorder(node->left);
        preorder(node->right);
    }

    void postorder(AVLNode<T>* node) {
        if (!node) return;
        postorder(node->left);
        postorder(node->right);
        cout << node->key << " ";
    }

public:
    AVLTree() : root(nullptr) {}
    ~AVLTree() { clear(root); }

    void insert(T key) { root = insertNode(root, key); }

    void displayInorder() { inorder(root); cout << endl; }
    void displayPreorder() { preorder(root); cout << endl; }
    void displayPostorder() { postorder(root); cout << endl; }
};
