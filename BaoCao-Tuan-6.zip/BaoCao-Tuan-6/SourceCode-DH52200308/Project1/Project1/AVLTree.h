﻿#pragma once
#include <iostream>
#include <algorithm>
#include <stdexcept>
#include <queue>
using namespace std;

template <typename T>
struct AVLNode {
    T key;
    int height;
    AVLNode* left;
    AVLNode* right;
    AVLNode(T val) : key(val), height(1), left(nullptr), right(nullptr) {}
};

template <typename T>
class AVLTree {
private:
    AVLNode<T>* root;

    int height(AVLNode<T>* node) { return node ? node->height : 0; }
    int getBalance(AVLNode<T>* node) { return node ? height(node->left) - height(node->right) : 0; }

    AVLNode<T>* rightRotate(AVLNode<T>* y) {
        AVLNode<T>* x = y->left;
        AVLNode<T>* T2 = x->right;
        x->right = y;
        y->left = T2;
        y->height = max(height(y->left), height(y->right)) + 1;
        x->height = max(height(x->left), height(x->right)) + 1;
        return x;
    }

    AVLNode<T>* leftRotate(AVLNode<T>* x) {
        AVLNode<T>* y = x->right;
        AVLNode<T>* T2 = y->left;
        y->left = x;
        x->right = T2;
        x->height = max(height(x->left), height(x->right)) + 1;
        y->height = max(height(y->left), height(y->right)) + 1;
        return y;
    }

    AVLNode<T>* insertNode(AVLNode<T>* node, T key) {
        if (!node) return new AVLNode<T>(key);
        if (key < node->key) node->left = insertNode(node->left, key);
        else if (key > node->key) node->right = insertNode(node->right, key);
        else return node;

        node->height = 1 + max(height(node->left), height(node->right));
        int balance = getBalance(node);

        if (balance > 1 && key < node->left->key) return rightRotate(node);
        if (balance < -1 && key > node->right->key) return leftRotate(node);
        if (balance > 1 && key > node->left->key) {
            node->left = leftRotate(node->left);
            return rightRotate(node);
        }
        if (balance < -1 && key < node->right->key) {
            node->right = rightRotate(node->right);
            return leftRotate(node);
        }
        return node;
    }

    void clear(AVLNode<T>* node) {
        if (!node) return;
        clear(node->left);
        clear(node->right);
        delete node;
    }

    // ===== 4 LOẠI LIỆT KÊ NODE =====
    void listHasLeft(AVLNode<T>* node) {
        if (!node) return;
        if (node->left) cout << node->key << " ";
        listHasLeft(node->left);
        listHasLeft(node->right);
    }

    void listHasRight(AVLNode<T>* node) {
        if (!node) return;
        if (node->right) cout << node->key << " ";
        listHasRight(node->left);
        listHasRight(node->right);
    }

    void listHasBoth(AVLNode<T>* node) {
        if (!node) return;
        if (node->left && node->right) cout << node->key << " ";
        listHasBoth(node->left);
        listHasBoth(node->right);
    }

    void listLeaf(AVLNode<T>* node) {
        if (!node) return;
        if (!node->left && !node->right) cout << node->key << " ";
        listLeaf(node->left);
        listLeaf(node->right);
    }

public:
    AVLTree() : root(nullptr) {}
    ~AVLTree() { clear(root); }

    void insert(T key) { root = insertNode(root, key); }

    // ===== 4 hàm public gọi ra từ main =====
    void listHasLeft() {
        cout << "Cac node co con trai: ";
        listHasLeft(root);
        cout << endl;
    }

    void listHasRight() {
        cout << "Cac node co con phai: ";
        listHasRight(root);
        cout << endl;
    }

    void listHasBoth() {
        cout << "Cac node co ca 2 con: ";
        listHasBoth(root);
        cout << endl;
    }

    void listLeaf() {
        cout << "Cac node la (khong co con): ";
        listLeaf(root);
        cout << endl;
    }

    // ===== DUYỆT CÂY =====
    void inOrder(AVLNode<T>* node) {
        if (!node) return;
        inOrder(node->left);
        cout << node->key << " ";
        inOrder(node->right);
    }
    void inOrder() { inOrder(root); cout << endl; }

    void preOrder(AVLNode<T>* node) {
        if (!node) return;
        cout << node->key << " ";
        preOrder(node->left);
        preOrder(node->right);
    }
    void preOrder() { preOrder(root); cout << endl; }

    void postOrder(AVLNode<T>* node) {
        if (!node) return;
        postOrder(node->left);
        postOrder(node->right);
        cout << node->key << " ";
    }
    void postOrder() { postOrder(root); cout << endl; }

    // ===== Duyệt theo tầng =====
    void levelOrder() {
        if (!root) { cout << "Cay rong!\n"; return; }
        queue<AVLNode<T>*> q; q.push(root);
        while (!q.empty()) {
            int n = q.size();
            while (n--) {
                AVLNode<T>* node = q.front(); q.pop();
                cout << node->key << " ";
                if (node->left) q.push(node->left);
                if (node->right) q.push(node->right);
            }
            cout << endl;
        }
    }

    void printLevels() {
        if (!root) { cout << "Cay rong!\n"; return; }
        queue<AVLNode<T>*> q; q.push(root);
        int level = 0;
        while (!q.empty()) {
            int n = q.size();
            cout << "Tang " << level << ": ";
            while (n--) {
                AVLNode<T>* node = q.front(); q.pop();
                cout << node->key << " ";
                if (node->left) q.push(node->left);
                if (node->right) q.push(node->right);
            }
            cout << endl;
            level++;
        }
    }

    /**/void printLevelK(int k) {
        if (!root) { cout << "Cay rong!\n"; return; }
        queue<AVLNode<T>*> q; q.push(root);
        int level = 0;
        while (!q.empty()) {
            int n = q.size();
            if (level == k) {
                cout << "Tang " << k << ": ";
                while (n--) {
                    AVLNode<T>* node = q.front(); q.pop();
                    cout << node->key << " ";
                    if (node->left) q.push(node->left);
                    if (node->right) q.push(node->right);
                }
                cout << endl;
                return;
            }
            else {
                while (n--) {
                    AVLNode<T>* node = q.front(); q.pop();
                    if (node->left) q.push(node->left);
                    if (node->right) q.push(node->right);
                }
                level++;
            }
        }
        cout << "Khong ton tai tang " << k << "!\n";
    }

    // ===== Các thuật toán bổ sung =====
    bool search(T key) {
        AVLNode<T>* current = root;
        while (current) {
            if (key == current->key) return true;
            else if (key < current->key) current = current->left;
            else current = current->right;
        }
        return false;
    }

    int getHeight() { return height(root); }

    bool isBalanced() {
        if (!root) return true;
        int balance = getBalance(root);
        return abs(balance) <= 1;
    }

    int countNodes(AVLNode<T>* node) {
        if (!node) return 0;
        return 1 + countNodes(node->left) + countNodes(node->right);
    }
    int countNodes() { return countNodes(root); }

    T findMin() {
        if (!root) throw runtime_error("Cay rong!");
        AVLNode<T>* current = root;
        while (current->left) current = current->left;
        return current->key;
    }

    T findMax() {
        if (!root) throw runtime_error("Cay rong!");
        AVLNode<T>* current = root;
        while (current->right) current = current->right;
        return current->key;
    }
};
