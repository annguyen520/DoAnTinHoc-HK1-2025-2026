﻿/*#include <iostream>
#include <filesystem>
#include <cctype>
#include "Header.h"
#include "AVLTree.h"
using namespace std;
namespace fs = std::filesystem;

int main() {
    string filename = "D:\\SourceCode-DH52200308\\Project1\\x64\\Debug\\student_exam_scores.csv";
    cout << "Dang doc file CSV...\n";

    auto data = read_csv(filename);
    cout << "Doc thanh cong!\n";
    cout << "So cot: " << data.size() << endl;

    if (data.empty()) {
        cerr << "Khong co du lieu trong file CSV!\n";
        return 1;
    }

    string outFile = "student_exam_scores.txt";
    write_to_txt(outFile, data);
    cout << "Da ghi toan bo du lieu vao " << outFile << " thanh cong!\n";

    // Khai báo các cây AVL cho từng cột
    AVLTree<int> tree_student_id;
    AVLTree<double> tree_hours_studied, tree_sleep_hours, tree_attendance, tree_prev_scores, tree_exam_score;

    size_t rows = data[0].second.size();
    cout << "So dong du lieu: " << rows << endl;

    // Đưa dữ liệu vào cây AVL
    for (size_t i = 0; i < rows; ++i) {
        const Cell& c0 = data[0].second[i];
        if (holds_alternative<int>(c0))
            tree_student_id.insert(get<int>(c0));
        else if (holds_alternative<double>(c0))
            tree_student_id.insert((int)get<double>(c0));
        else if (holds_alternative<string>(c0)) {
            string s = get<string>(c0), digits;
            for (char ch : s) if (isdigit(ch)) digits += ch;
            if (!digits.empty()) {
                try { tree_student_id.insert(stoi(digits)); }
                catch (...) {}
            }
        }

        auto insertDouble = [](AVLTree<double>& t, const Cell& c) {
            if (holds_alternative<double>(c))
                t.insert(get<double>(c));
            else if (holds_alternative<int>(c))
                t.insert((double)get<int>(c));
            };

        insertDouble(tree_hours_studied, data[1].second[i]);
        insertDouble(tree_sleep_hours, data[2].second[i]);
        insertDouble(tree_attendance, data[3].second[i]);
        insertDouble(tree_prev_scores, data[4].second[i]);
        insertDouble(tree_exam_score, data[5].second[i]);
    }

    cout << "\nDa xay dung thanh cong cac cay AVL!\n";
    cout << "\n=== KET QUA DUYET CAY ===\n";

    auto printAll = [](auto& name, auto& tree) {
        cout << "\n--- " << name << " ---\n";
        cout << "In-order  (LNR): "; tree.displayInorder();
        cout << "Pre-order (NLR): "; tree.displayPreorder();
        cout << "Post-order(LRN): "; tree.displayPostorder();
        };

    printAll("STUDENT ID", tree_student_id);
    printAll("HOURS STUDIED", tree_hours_studied);
    printAll("SLEEP HOURS", tree_sleep_hours);
    printAll("ATTENDANCE PERCENT", tree_attendance);
    printAll("PREVIOUS SCORES", tree_prev_scores);
    printAll("EXAM SCORE", tree_exam_score);

    cout << "\n=== KIEM TRA CAC HAM BO SUNG ===\n";

    // Ví dụ kiểm thử với cây điểm thi
    cout << "So node trong cay EXAM SCORE: " << tree_exam_score.size() << endl;
    cout << "Chieu cao cay EXAM SCORE: " << tree_exam_score.getHeight() << endl;

    try {
        cout << "Gia tri nho nhat trong EXAM SCORE: " << tree_exam_score.findMin() << endl;
        cout << "Gia tri lon nhat trong EXAM SCORE: " << tree_exam_score.findMax() << endl;
    }
    catch (const exception& e) {
        cerr << "Loi: " << e.what() << endl;
    }

    double testScore = 40.3;
    if (tree_exam_score.search(testScore))
        cout << "Tim thay diem " << testScore << " trong cay!\n";
    else
        cout << "Khong tim thay diem " << testScore << " trong cay!\n";

    cout << "Xoa diem " << testScore << " khoi cay...\n";
    tree_exam_score.remove(testScore);

    cout << "Duyet lai cay EXAM SCORE sau khi xoa:\n";
    tree_exam_score.displayInorder();

    cout << "\nDa ghi file student_exam_scores.txt va xay dung cay AVL hoan tat!\n";
    return 0;
}*/
#include <sstream>
#include <iomanip>
#include <sstream>
#include <iomanip>
#include <iostream>
#include <filesystem>
#include <cctype>
#include <cmath>
#include "Header.h"
#include "AVLTree.h"

using namespace std;
namespace fs = std::filesystem;

// Hàm lấy giá trị số từ Cell
double extractNumeric(const Cell& c) {
    if (holds_alternative<int>(c)) return get<int>(c);
    if (holds_alternative<double>(c)) return get<double>(c);
    if (holds_alternative<string>(c)) {
        string s = get<string>(c), digits;
        for (char ch : s) {
            if (isdigit(ch) || ch == '.') digits += ch;
        }
        try { return stod(digits); }
        catch (...) { return 0.0; }
    }
    return 0.0;
}

int main() {
    string filename = "D:\\SourceCode-DH52200308\\Project1\\x64\\Debug\\student_exam_scores.csv";
    cout << "Dang doc file CSV...\n";

    auto data = read_csv(filename);
    cout << "Doc thanh cong!\n";

    if (data.empty()) {
        cerr << "Khong co du lieu trong file CSV!\n";
        return 1;
    }

    cout << "So cot: " << data.size() << endl;

    string outFile = "student_exam_scores.txt";
    write_to_txt(outFile, data);
    cout << "Da ghi toan bo du lieu vao " << outFile << " thanh cong!\n";

    size_t rows = data[0].second.size();
    size_t cols = data.size();
    cout << "So dong du lieu: " << rows << endl;

    // Mỗi dòng dữ liệu -> một cây AVL riêng (dùng double)
    vector<AVLTree<double>> listTrees(rows);

    for (size_t i = 0; i < rows; ++i) {
        for (size_t j = 0; j < cols; ++j) {
            double val = extractNumeric(data[j].second[i]);
            listTrees[i].insert(val);
        }
    }

    cout << "\nDa xay dung " << rows << " cay AVL (moi dong la 1 cay).\n";

    int rowIndex;
    while (true) {
        cout << "\nNhap chi so dong (0.." << rows - 1 << ", -1 de thoat): ";
        cin >> rowIndex;
        if (rowIndex == -1) break;

        if (rowIndex >= 0 && rowIndex < (int)rows) {
            int choice;
            cout << "Chon chuc nang:\n"
                << " (1) Toan bo cay (level-order)\n"
                << " (2) Tung tang co nhan\n"
                << " (3) In tang k\n"
                << " (4) Thong tin cay (so nut, chieu cao, can bang)\n"
                << " (5) Duyet cay (In-Order, Pre-Order, Post-Order)\n"
                << " (6) Tim min/max\n"
                << " (7) Tim kiem gia tri\n"
                << " (8) Liet ke node (trai/phai/hai con/la)\n"
                << "Lua chon: ";
            cin >> choice;

            if (choice == 1) {
                cout << "\nCay AVL cua dong " << rowIndex << " (level-order):\n";
                listTrees[rowIndex].levelOrder();
            }
            else if (choice == 2) {
                cout << "\nCay AVL cua dong " << rowIndex << " (hien thi tung tang co nhan):\n";
                listTrees[rowIndex].printLevels();
            }
            else if (choice == 3) {
                int k;
                cout << "Nhap so tang k: ";
                cin >> k;
                listTrees[rowIndex].printLevelK(k);
            }
            else if (choice == 4) {
                cout << "So nut trong cay: " << listTrees[rowIndex].countNodes() << endl;
                cout << "Chieu cao cay: " << listTrees[rowIndex].getHeight() << endl;
                cout << "Cay co can bang khong? "
                    << (listTrees[rowIndex].isBalanced() ? "Co" : "Khong") << endl;
            }
            else if (choice == 5) {
                cout << "Duyet In-Order: "; listTrees[rowIndex].inOrder();
                cout << "Duyet Pre-Order: "; listTrees[rowIndex].preOrder();
                cout << "Duyet Post-Order: "; listTrees[rowIndex].postOrder();
            }
            else if (choice == 6) {
                cout << "Gia tri nho nhat: " << listTrees[rowIndex].findMin() << endl;
                cout << "Gia tri lon nhat: " << listTrees[rowIndex].findMax() << endl;
            }
            else if (choice == 7) {
                double x;
                cout << "Nhap gia tri can tim: ";
                cin >> x;
                cout << "Ket qua tim kiem: "
                    << (listTrees[rowIndex].search(x) ? "Tim thay" : "Khong tim thay") << endl;
            }
            else if (choice == 8) {
                cout << "\n--- LIET KE CAC LOAI NODE ---\n";
                listTrees[rowIndex].listHasLeft();
                listTrees[rowIndex].listHasRight();
                listTrees[rowIndex].listHasBoth();
                listTrees[rowIndex].listLeaf();
            }
            else {
                cout << "Lua chon khong hop le!\n";
            }
        }
        else {
            cout << "Chi so dong khong hop le!\n";
        }
    }

    cout << "Ket thuc chuong trinh.\n";
    return 0;
}
